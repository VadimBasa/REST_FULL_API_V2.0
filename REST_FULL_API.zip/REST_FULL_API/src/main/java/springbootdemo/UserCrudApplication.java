package springbootdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import springbootdemo.model.User;

@SpringBootApplication
public class UserCrudApplication {

	public static void main(String[] args) {
		//Facade facade = new Facade();
		/*User user = new User();
		Facade facade = new Facade();
		facade.save(user);
		facade.finaAll();
		facade.findId(user.getId());
		facade.deleteId(user.getId());*/


		SpringApplication.run(UserCrudApplication.class, args); //
		/*@GetMapping("/hello")
		public String hello(@RequestParam(value = "name", defaultValue = "читатель Skillbox Media") String name) {
			return String.format("Hello, %s!", name);
		}*/
	}

}
