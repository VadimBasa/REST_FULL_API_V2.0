package springbootdemo;

import springbootdemo.model.User;
import springbootdemo.service.UserService;

import java.util.List;

public class Facade {
    private UserService userService;

    public Facade() {
        userService = new UserService();
    }
    public void save(User user) {
        userService.saveUser(user);
    }
    public User findId(Long id) {

        //return User;
        return userService.findById(id);
    }
    public List<User> finaAll() {
        return userService.findAll();
    }
    public void deleteId(Long id) {
        userService.deleteById(id);
    }

}
